<?php

namespace Braintree\Exception;

use Braintree\Exception;

/**
 * Raised when a record could not be found.
 */
class NotFound extends Exception
{
}
