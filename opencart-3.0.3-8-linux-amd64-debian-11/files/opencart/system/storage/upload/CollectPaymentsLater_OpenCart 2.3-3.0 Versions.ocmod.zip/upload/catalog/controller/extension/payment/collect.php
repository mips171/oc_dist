<?php
//==============================================================================
// Collect Payment Later v2023-5-05
// 
// Author: Clear Thinking, LLC
// E-mail: johnathan@getclearthinking.com
// Website: http://www.getclearthinking.com
// 
// All code within this file is copyright Clear Thinking, LLC.
// You may not copy or reuse code within this file without written permission.
//==============================================================================

//namespace Opencart\Catalog\Controller\Extension\CollectPaymentLater\Payment;
//class Collect extends \Opencart\System\Engine\Controller {

class ControllerExtensionPaymentCollect extends Controller {
	
	private $extension = 'collect_payment_later';
	private $type = 'payment';
	private $name = 'collect';
	
	//==============================================================================
	// index()
	//==============================================================================
	public function index() {
		$settings = $this->getSettings();
		$data['type'] = $this->type;
		$data['name'] = $this->name;
		
		// Check for query string variables
		if (empty($this->request->get['order_id']) || empty($this->request->get['key'])) {
			echo 'No order_id or key';
			return;
		}
		
		// Check for correct key
		$order_id = $this->request->get['order_id'];
		
		if ($this->request->get['key'] != md5($this->config->get('config_encryption') . $order_id)) {
			echo 'Invalid key';
			return;
		}
		
		// Check for already completed payment
		if ($settings['allow_payment_once']) {
			$order_history_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_history WHERE order_id = " . (int)$order_id . " AND order_status_id > 0 AND `comment` = 'Customer completed payment'");
			if ($order_history_query->num_rows) {
				$this->response->redirect($this->url->link('common/home'));
			}
		}
		
		// Check for valid order info
		$this->load->model('checkout/order');
		$order_info = $this->model_checkout_order->getOrder($order_id);
		$data['order_info'] = $order_info;
		
		if (empty($order_info)) {
			echo 'No valid order info';
			return;
		}
		
		// Check if customer is required to be logged in
		if ($settings['require_logged']) {
			if (!$this->customer->isLogged()) {
				$this->session->data['redirect'] = $this->url->link('extension/' . $this->type . '/' . $this->name, 'order_id=' . $order_id . '&key=' . $this->request->get['key'], 'SSL');
				$this->response->redirect($this->url->link('account/login', '', 'SSL'));
			} else {
				if ($this->customer->getId() != $order_info['customer_id']) {
					$this->response->redirect($this->url->link('common/home'));
				}
			}
		}
		
		// Check if customer has cancelled their order
		$order_history_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_history WHERE order_id = " . (int)$order_id . " AND order_status_id > 0 AND `comment` LIKE '%Order canceled by customer%'");
		if ($order_history_query->num_rows) {
			$this->response->redirect($this->url->link('common/home'));
		}
		
		// Get language data and set session data
		$data = array_merge($data, $this->load->language('checkout/cart'));
		$data = array_merge($data, $this->load->language('account/order'));
		$data['logo'] = 'image/' . $this->config->get('config_logo');
		$data['language'] = $this->db->query("SELECT * FROM " . DB_PREFIX . "language WHERE language_id = " . (int)$order_info['language_id'])->row['code'];
		
		if ($data['language'] != $this->session->data['language']) {
			$this->session->data['language'] = $data['language'];
			$this->response->redirect($this->url->link('extension/' . $this->type . '/' . $this->name, 'order_id=' . $order_id . '&key=' . $this->request->get['key'], 'SSL'));
		}
		
		$this->session->data['order_id'] = $order_id;
		$this->session->data['currency'] = $order_info['currency_code'];
		$this->session->data['guest'] = array(
			'firstname'	=> $order_info['firstname'],
			'lastname'	=> $order_info['lastname'],
		);
		
		// Set pop-up for terms and conditions if enabled
		$data['terms_popup'] = '';
		
		if ($settings['show_terms_popup']) {
			$this->load->language('checkout/checkout');
			$this->load->model('catalog/information');

			$information_info = $this->model_catalog_information->getInformation($this->config->get('config_checkout_id'));

			if ($information_info) {
				$data['text_yes'] = $this->language->get('text_yes');
				$data['text_no'] = $this->language->get('text_no');
				$data['terms_popup'] = sprintf($this->language->get('text_agree'), $this->url->link('information/information', 'information_id=' . $this->config->get('config_checkout_id'), 'SSL'), $information_info['title'], $information_info['title']);
				$data['terms_popup'] = str_replace(array('<a', 'class="agree"'), array('<a target="_blank"', ''), $data['terms_popup']);
			}
		}
		
		// Get order products and line items
		$this->load->model('tool/image');
		
		$data['order_products'] = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = " . (int)$order_id . " ORDER BY order_product_id ASC")->rows;
		$data['line_items'] = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_total WHERE order_id = " . (int)$order_id . " ORDER BY sort_order ASC")->rows;
		
		foreach ($data['order_products'] as &$order_product) {
			$product_info = $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product WHERE product_id = " . (int)$order_product['product_id'])->row;
			$order_product['image'] = $this->model_tool_image->resize($product_info['image'], 50, 50);
			
			$order_options = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_product_id = " . (int)$order_product['order_product_id'] . " ORDER BY order_option_id ASC")->rows;
			foreach ($order_options as $order_option) {
				$order_product['name'] .= '<br><span style="font-size: 11px">- ' . $order_option['name'] . ': ' . $order_option['value'] . '</span>';
			}
			
			$order_product['price'] = $this->currency->format($order_product['price'], $order_info['currency_code'], $order_info['currency_value']);
			$order_product['total'] = $this->currency->format($order_product['total'], $order_info['currency_code'], $order_info['currency_value']);
		}
		
		foreach ($data['line_items'] as &$line_item) {
			$line_item['value'] = (!empty($line_item['text'])) ? $line_item['text'] : $this->currency->format($line_item['value'], $order_info['currency_code'], $order_info['currency_value']);
		}
		
		// Set up cart data
		$this->cart->clear();
		
		foreach ($data['order_products'] as $product) {
			$options = array();
			
			$options_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = " . (int)$order_id);
			if ($options_query->num_rows) {
				foreach ($options_query->rows as $option) {
					if (isset($options[$option['product_option_id']])) {
						if (!is_array($options[$option['product_option_id']])) $options[$option['product_option_id']] = array($options[$option['product_option_id']]);
						$options[$option['product_option_id']][] = (!empty($option['product_option_value_id'])) ? $option['product_option_value_id'] : $option['value'];
					} else {
						$options[$option['product_option_id']] = (!empty($option['product_option_value_id'])) ? $option['product_option_value_id'] : $option['value'];
					}
				}
			}
			
			$this->cart->add($product['product_id'], $product['quantity'], $options);
		}
		
		// Get payment methods
		$payment_address = array();
		foreach ($order_info as $key => $value) {
			if (strpos($key, 'payment_') === 0) {
				$payment_address[str_replace('payment_', '', $key)] = $value;
			}
		}
		
		if (version_compare(VERSION, '3.0', '<')) {
			$this->load->model('extension/extension');
			$payment_methods = $this->model_extension_extension->getExtensions('payment');
		} elseif (version_compare(VERSION, '4.0', '<')) {
			$this->load->model('setting/extension');
			$payment_methods = $this->model_setting_extension->getExtensions('payment');
		} else {
			$this->load->model('setting/extension');
			$payment_methods = $this->model_setting_extension->getExtensionsByType('payment');
		}
		
		//$payment_methods = $this->db->query("SELECT * FROM `" . DB_PREFIX . "extension` WHERE `type` = 'payment' ORDER BY `code` ASC")->rows;
		
		$eligible_payment_methods = explode(';', $settings['payment_methods']);
		$data['payment_methods'] = array();
		
		foreach ($payment_methods as $result) {
			if ($result['code'] == $this->extension) continue;
			if ($result['code'] == 'pp_express') continue;
			if (!empty($eligible_payment_methods) && !in_array($result['code'], $eligible_payment_methods)) continue;
			
			// Fix for PayPal Payflow Pro iFrame bug
			if ($result['code'] == 'pp_payflow_iframe') {
				$this->db->query("DELETE FROM " . DB_PREFIX . "paypal_payflow_iframe_order WHERE order_id = " . (int)$order_id);
			}
			
			// Load payment methods
			$prefix = (version_compare(VERSION, '3.0', '<')) ? '' : 'payment_';
			
			$enabled = $this->config->get($prefix . $result['code'] . '_status');
			if (!$enabled) {
				$this->config->set($prefix . $result['code'] . '_status', 1);
				$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = 1 WHERE `key` = '" . $prefix . $result['code'] . "_status'");
			}
			
			if (version_compare(VERSION, '2.3', '<')) {
				$this->load->model('payment/' . $result['code']);
				$method = $this->{'model_payment_' . $result['code']}->getMethod($payment_address, $order_info['total']);
			} elseif (version_compare(VERSION, '4.0', '<')) {
				$this->load->model('extension/payment/' . $result['code']);
				$method = $this->{'model_extension_payment_' . $result['code']}->getMethod($payment_address, $order_info['total']);
			} elseif (version_compare(VERSION, '4.0.2.0', '<')) {
				$this->load->model('extension/' . $result['extension'] . '/payment/' . $result['code']);
				$method = $this->{'model_extension_' . $result['extension'] . '_payment_' . $result['code']}->getMethod($payment_address);
			} else {
				$this->load->model('extension/' . $result['extension'] . '/payment/' . $result['code']);
				$method = $this->{'model_extension_' . $result['extension'] . '_payment_' . $result['code']}->getMethods($payment_address);
			}
			
			if (!$enabled) {
				$this->config->set($prefix . $result['code'] . '_status', 0);
				$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = 0 WHERE `key` = '" . $prefix . $result['code'] . "_status'");
			}
			
			if (empty($method)) continue;
			$data['payment_methods'][$result['code']] = $method;
		}

		$sort_order = array();
		foreach ($data['payment_methods'] as $key => $value) $sort_order[$key] = $value['sort_order'];
		array_multisort($sort_order, SORT_ASC, $data['payment_methods']);
		
		$this->session->data['payment_methods'] = $data['payment_methods'];
		if (version_compare(VERSION, '4.0', '<')) {
			$data['selected_payment_method'] = (isset($this->session->data['payment_method']['code'])) ? $this->session->data['payment_method']['code'] : '';
		} else {
			$data['selected_payment_method'] = (isset($this->session->data['payment_method'])) ? $this->session->data['payment_method'] : '';
		}
		
		// Clear cart data
		$this->cart->clear();
		
		// Set session variable
		$this->session->data['payment_in_process'] = true;
		
		// Render
		$this->document->setTitle($data['text_order_id'] . ' #' . $order_id);
		$data['header'] = $this->load->controller('common/header');
		
		$theme = (version_compare(VERSION, '2.2', '<')) ? $this->config->get('config_template') : $this->config->get('theme_default_directory');
		$template = (file_exists(DIR_TEMPLATE . $theme . '/template/extension/' . $this->type . '/' . $this->name . '.twig')) ? $theme : 'default';
		
		if (version_compare(VERSION, '4.0', '<')) {
			$template_file = DIR_TEMPLATE . $template . '/template/extension/' . $this->type . '/' . $this->name . '.twig';
		} elseif (defined('DIR_EXTENSION')) {
			$template_file = DIR_EXTENSION . $this->extension . '/catalog/view/template/' . $this->type . '/' . $this->name . '.twig';
		}
		
		if (is_file($template_file)) {
			extract($data);
			
			ob_start();
			if (version_compare(VERSION, '4.0', '<')) {
				require(class_exists('VQMod') ? \VQMod::modCheck(modification($template_file)) : modification($template_file));
			} else {
				require(class_exists('VQMod') ? \VQMod::modCheck($template_file) : $template_file);
			}
			$output = ob_get_clean();
			
			if (version_compare(VERSION, '4.0', '>=')) {
				$separator = (version_compare(VERSION, '4.0.2.0', '<')) ? '|' : '.';
				$output = str_replace($settings['extension_route'] . '/', $settings['extension_route'] . $separator, $output);
			}
			
			echo $output;
		} else {
			echo 'Error loading template file: ' . $template_file;
		}
	}
	
	//==============================================================================
	// getSettings()
	//==============================================================================
	private function getSettings() {
		//$code = (version_compare(VERSION, '3.0', '<') ? '' : $this->type . '_') . $this->name;
		$code = (version_compare(VERSION, '3.0', '<')) ? $this->extension : $this->type . '_' . $this->extension;
		
		$settings = array();
		$settings_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE `code` = '" . $this->db->escape($code) . "' ORDER BY `key` ASC");
		
		foreach ($settings_query->rows as $setting) {
			$value = $setting['value'];
			if ($setting['serialized']) {
				$value = (version_compare(VERSION, '2.1', '<')) ? unserialize($setting['value']) : json_decode($setting['value'], true);
			}
			$split_key = preg_split('/_(\d+)_?/', str_replace($code . '_', '', $setting['key']), -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
			
				if (count($split_key) == 1)	$settings[$split_key[0]] = $value;
			elseif (count($split_key) == 2)	$settings[$split_key[0]][$split_key[1]] = $value;
			elseif (count($split_key) == 3)	$settings[$split_key[0]][$split_key[1]][$split_key[2]] = $value;
			elseif (count($split_key) == 4)	$settings[$split_key[0]][$split_key[1]][$split_key[2]][$split_key[3]] = $value;
			else 							$settings[$split_key[0]][$split_key[1]][$split_key[2]][$split_key[3]][$split_key[4]] = $value;
		}
		
		if (version_compare(VERSION, '4.0', '<')) {
			$settings['extension_route'] = 'extension/' . $this->type . '/' . $this->name;
		} else {
			$settings['extension_route'] = 'extension/' . $this->extension . '/' . $this->type . '/' . $this->name;
		}
		
		return $settings;
	}
	
	//==============================================================================
	// cancelOrder()
	//==============================================================================
	public function cancelOrder() {
		if (empty($this->request->post['order_id']) || empty($this->request->post['key'])) {
			return;
		}
		
		if ($this->request->post['key'] != md5($this->config->get('config_encryption') . $this->request->post['order_id'])) {
			echo 'Invalid key';
			return;
		}
		
		if (version_compare(VERSION, '4.0', '<')) {
			$this->load->model('extension/' . $this->type . '/' . $this->extension);
			$collect_payment_later = $this->{'model_extension_' . $this->type . '_' . $this->extension};
		} else {
			$this->load->model('extension/' . $this->extension . '/' . $this->type . '/' . $this->extension);
			$collect_payment_later = $this->{'model_extension_' . $this->extension . '_' . $this->type . '_' . $this->extension};
		}
		
		$collect_payment_later->cancelOrder($this->request->post['order_id'], $this->request->post['reason']);
	}
	
	//==============================================================================
	// getPaymentTemplate()
	//==============================================================================
	public function getPaymentTemplate() {
		$settings = $this->getSettings();
		$prefix = (version_compare(VERSION, '3.0', '<')) ? '' : 'total_';
		
		if (version_compare(VERSION, '4.0', '<')) {
			$this->session->data['payment_method'] = $this->session->data['payment_methods'][$this->request->get['code']];
		} else {
			$this->session->data['payment_method'] = $this->request->get['code'];
		}
		
		// Check for "text" column
		$text_column = false;
		$column_query = $this->db->query("DESCRIBE " . DB_PREFIX . "order_total");
		
		foreach ($column_query->rows as $column) {
			if ($column['Field'] == 'text') {
				$text_column = true;
			}
		}
		
		// Get order info
		$this->load->model('checkout/order');
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		$old_total = $order_info['total'];
		$language = (isset($this->session->data['language'])) ? $this->session->data['language'] : $this->config->get('config_language');
		
		//$tax_rate = 0.21;
		
		// Remove current fees and discounts
		$current_value_query = $this->db->query("SELECT SUM(value) AS total FROM " . DB_PREFIX . "order_total WHERE order_id = " . (int)$order_info['order_id'] . " AND (title = '" . $this->db->escape($settings['text_payment_fee_' . $language]) . "' OR title = '" . $this->db->escape($settings['text_payment_discount_' . $language]) . "')");
		
		if ($current_value_query->num_rows) {
			$order_info['total'] -= $current_value_query->row['total'];
			
			// Hard-coded update to "Taxes" line item
			/*
			$amount_to_remove = $current_value_query->row['total'] * $tax_rate;
			$this->db->query("UPDATE " . DB_PREFIX . "order_total SET `value` = (`value` - " . (float)$amount_to_remove . ") WHERE order_id = " . (int)$order_info['order_id'] . " AND `code` = 'tax'");
			$order_info['total'] -= $amount_to_remove;
			*/
			
			// Update total
			$this->db->query("UPDATE `" . DB_PREFIX . "order` SET total = " . (float)$order_info['total'] . " WHERE order_id = " . (int)$order_info['order_id']);
			
			if (!$text_column) {
				$this->db->query("UPDATE " . DB_PREFIX . "order_total SET `value` = " . (float)$order_info['total'] . " WHERE order_id = " . (int)$order_info['order_id'] . " AND `code` = 'total' AND sort_order = " . (int)$this->config->get($prefix . 'total_sort_order'));
			} else {
				$this->db->query("UPDATE " . DB_PREFIX . "order_total SET `value` = " . (float)$order_info['total'] . ", `text` = '" . $this->db->escape($this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'])) . "' WHERE order_id = " . (int)$order_info['order_id'] . " AND `code` = 'total' AND sort_order = " . (int)$this->config->get($prefix . 'total_sort_order'));
			}
		}
		
		$this->db->query("DELETE FROM " . DB_PREFIX . "order_total WHERE title = '" . $this->db->escape($settings['text_payment_fee_' . $language]) . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "order_total WHERE title = '" . $this->db->escape($settings['text_payment_discount_' . $language]) . "'");
		
		$new_total = $order_info['total'];
		
		// Add fees or discounts if they apply
		if (!empty($settings['fee_' . $this->request->get['code']])) {
			// Calculate fee
			$explode = explode('+', $settings['fee_' . $this->request->get['code']]);
			
			$cost = (strpos($explode[0], '%')) ? (float)$explode[0] / 100 * $order_info['total'] : (float)$explode[0];
			if (isset($explode[1])) {
				$cost += (strpos($explode[1], '%')) ? (float)$explode[1] / 100 * $order_info['total'] : (float)$explode[1];
			}
			$cost = round($cost, 4);
			
			if (!empty($cost)) {
				// Modify order
				$total_sort_order = $this->config->get($prefix . 'total_sort_order');
				$line_item_title = ($cost > 0) ? $settings['text_payment_fee_' . $language] : $settings['text_payment_discount_' . $language];
				$new_total = $order_info['total'] + $cost;
				
				// Hard-coded update to "Taxes" line item
				/*
				$tax_to_add = $cost * $tax_rate;
				$this->db->query("UPDATE " . DB_PREFIX . "order_total SET `value` = (`value` + " . (float)$tax_to_add . ") WHERE order_id = " . (int)$order_info['order_id'] . " AND `code` = 'tax'");
				$new_total += $tax_to_add;
				*/
				
				// Update total
				$this->db->query("UPDATE `" . DB_PREFIX . "order` SET total = " . (float)$new_total . " WHERE order_id = " . (int)$order_info['order_id']);
				
				if (!$text_column) {
					$this->db->query("UPDATE " . DB_PREFIX . "order_total SET `value` = " . (float)$new_total . " WHERE order_id = " . (int)$order_info['order_id'] . " AND `code` = 'total'");
					$this->db->query("INSERT INTO " . DB_PREFIX . "order_total SET order_id = " . (int)$order_info['order_id'] . ", `code` = 'handling', title = '" . $this->db->escape($line_item_title) . "', `value` = " . (float)$cost . ", sort_order = " . (int)($total_sort_order - 1));
				} else {
					$this->db->query("UPDATE " . DB_PREFIX . "order_total SET `value` = " . (float)$new_total . ", `text` = '" . $this->db->escape($this->currency->format($new_total, $order_info['currency_code'], $order_info['currency_value'])) . "' WHERE order_id = " . (int)$order_info['order_id'] . " AND `code` = 'total' AND sort_order = " . (int)$this->config->get($prefix . 'total_sort_order'));
					$this->db->query("INSERT INTO " . DB_PREFIX . "order_total SET order_id = " . (int)$order_info['order_id'] . ", `code` = 'handling', title = '" . $this->db->escape($line_item_title) . "', `text` = '" . $this->db->escape($this->currency->format($cost, $order_info['currency_code'], $order_info['currency_value'])) . "', `value` = " . (float)$cost . ", sort_order = " . (int)($total_sort_order - 1));
				}
				
				// Update Intermediate Order Total if installed
				if ($this->config->get($prefix . 'intermediate_order_total_status')) {
					$cumulative_total = 0;
					$order_totals = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_total WHERE order_id = " . (int)$order_info['order_id'] . " ORDER BY sort_order ASC")->rows;
					
					foreach ($order_totals as $line_item) {
						if ($line_item['code'] == 'intermediate_order_total') {
							$this->db->query("UPDATE " . DB_PREFIX . "order_total SET `value` = " . (float)$cumulative_total . " WHERE order_id = " . (int)$order_info['order_id'] . " AND `code` = 'intermediate_order_total'");
							break;
						} else {
							$cumulative_total += $line_item['value'];
						}
					}
				}
			}
		}
		
		// Reload if order has changed
		if ($new_total != $old_total) {
			echo 'reload';
			return;
		}
			
		// Return payment template data
		$this->cart->clear();
		$order_products = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = " . (int)$order_info['order_id'] . " ORDER BY order_product_id ASC")->rows;
		
		foreach ($order_products as $product) {
			$options = array();
			
			$options_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = " . (int)$order_info['order_id']);
			if ($options_query->num_rows) {
				foreach ($options_query->rows as $option) {
					if (isset($options[$option['product_option_id']])) {
						if (!is_array($options[$option['product_option_id']])) $options[$option['product_option_id']] = array($options[$option['product_option_id']]);
						$options[$option['product_option_id']][] = (!empty($option['product_option_value_id'])) ? $option['product_option_value_id'] : $option['value'];
					} else {
						$options[$option['product_option_id']] = (!empty($option['product_option_value_id'])) ? $option['product_option_value_id'] : $option['value'];
					}
				}
			}
			
			$this->cart->add($product['product_id'], $product['quantity'], $options);
		}
		
		if (version_compare(VERSION, '2.3', '<')) {
			echo $this->load->controller('payment/' . $this->request->get['code']);
		} elseif (version_compare(VERSION, '4.0', '<')) {
			echo $this->load->controller('extension/payment/' . $this->request->get['code']);
		} else {
			$extension = $this->db->query("SELECT * FROM " . DB_PREFIX . "extension WHERE `code` = '" . $this->db->escape($this->request->get['code']) . "'")->row;
			echo $this->load->controller('extension/' . $extension['extension'] . '/payment/' . $this->request->get['code']);
		}
		
		$this->cart->clear();
	}
}
?>