<?php
//==============================================================================
// Collect Payment Later v2023-5-05
// 
// Author: Clear Thinking, LLC
// E-mail: johnathan@getclearthinking.com
// Website: http://www.getclearthinking.com
// 
// All code within this file is copyright Clear Thinking, LLC.
// You may not copy or reuse code within this file without written permission.
//==============================================================================

//namespace Opencart\Catalog\Model\Extension\CollectPaymentLater\Payment;
//class CollectPaymentLater extends \Opencart\System\Engine\Model {

class ModelExtensionPaymentCollectPaymentLater extends Model {
	
	private $type = 'payment';
	private $name = 'collect_payment_later';
	
	//==============================================================================
	// getMethods()
	//==============================================================================
	public function getMethods($address) {
		$method_data = $this->getMethod($address);
		
		$option_data[$this->name] = array(
			'code'	=> $this->name . '.' . $this->name,
			'name'	=> $method_data['title'],
		);
		
		return array(
			'code'			=> $this->name,
			'name'			=> $method_data['title'],
			'option'		=> $option_data,
			'sort_order'	=> $method_data['sort_order'],
		);
	}
	
	//==============================================================================
	// getMethod()
	//==============================================================================
	public function getMethod($address, $total = 0) {
		$settings = $this->getSettings();
		
		$current_geozones = array();
		$geozones = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE country_id = " . (int)$address['country_id'] . " AND (zone_id = 0 OR zone_id = " . (int)$address['zone_id'] . ")");
		foreach ($geozones->rows as $geozone) $current_geozones[] = $geozone['geo_zone_id'];
		if (empty($current_geozones)) $current_geozones = array(0);
		
		$language = (isset($this->session->data['language'])) ? $this->session->data['language'] : $this->config->get('config_language');
		
		if (empty($total)) {
			$order_totals = $this->getOrderTotals();
			$total = $order_totals['total'];
		}
		
		if (!$settings['status'] ||
			($settings['min_total'] && (float)$settings['min_total'] > $total) ||
			($settings['max_total'] && (float)$settings['max_total'] < $total) ||
			!array_intersect(array($this->config->get('config_store_id')), explode(';', $settings['stores'])) ||
			!array_intersect($current_geozones, explode(';', $settings['geo_zones'])) ||
			!array_intersect(array((int)$this->customer->getGroupId()), explode(';', $settings['customer_groups'])) ||
			!array_intersect(array($this->session->data['currency']), explode(';', $settings['currencies']))
		) {
			return array();
		} else {
			return array(
				'code'			=> $this->name,
				'sort_order'	=> $settings['sort_order'],
				'terms'			=> '',
				'title'			=> html_entity_decode($settings['title_' . $language], ENT_QUOTES, 'UTF-8'),
			);
		}
	}
	
	//==============================================================================
	// getSettings()
	//==============================================================================
	private function getSettings() {
		$code = (version_compare(VERSION, '3.0', '<') ? '' : $this->type . '_') . $this->name;
		
		$settings = array();
		$settings_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE `code` = '" . $this->db->escape($code) . "' ORDER BY `key` ASC");
		
		foreach ($settings_query->rows as $setting) {
			$value = $setting['value'];
			if ($setting['serialized']) {
				$value = (version_compare(VERSION, '2.1', '<')) ? unserialize($setting['value']) : json_decode($setting['value'], true);
			}
			$split_key = preg_split('/_(\d+)_?/', str_replace($code . '_', '', $setting['key']), -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
			
				if (count($split_key) == 1)	$settings[$split_key[0]] = $value;
			elseif (count($split_key) == 2)	$settings[$split_key[0]][$split_key[1]] = $value;
			elseif (count($split_key) == 3)	$settings[$split_key[0]][$split_key[1]][$split_key[2]] = $value;
			elseif (count($split_key) == 4)	$settings[$split_key[0]][$split_key[1]][$split_key[2]][$split_key[3]] = $value;
			else 							$settings[$split_key[0]][$split_key[1]][$split_key[2]][$split_key[3]][$split_key[4]] = $value;
		}
		
		if (version_compare(VERSION, '4.0', '<')) {
			$settings['extension_route'] = 'extension/' . $this->type . '/' . $this->name;
		} else {
			$settings['extension_route'] = 'extension/' . $this->name . '/' . $this->type . '/' . $this->name;
		}
		
		return $settings;
	}
	
	//==============================================================================
	// getOrderTotals()
	//==============================================================================
	private function getOrderTotals($stop_before = '') {
		$prefix = (version_compare(VERSION, '3.0', '<')) ? '' : 'total_';
		$order_total_extensions = $this->db->query("SELECT * FROM " . DB_PREFIX . "extension WHERE `type` = 'total' ORDER BY `code` ASC")->rows;
		
		$sort_order = array();
		foreach ($order_total_extensions as $key => $value) {
			$sort_order[$key] = $this->config->get($prefix . $value['code'] . '_sort_order');
		}
		array_multisort($sort_order, SORT_ASC, $order_total_extensions);
		
		$order_totals = array();
		$total = 0;
		$taxes = $this->cart->getTaxes();
		$reference_array = array('totals' => &$order_totals, 'total' => &$total, 'taxes' => &$taxes);
		
		foreach ($order_total_extensions as $ot) {
			if (!empty($stop_before) && $ot['code'] == $stop_before) {
				break;
			}
			if (!$this->config->get($prefix . $ot['code'] . '_status') || $ot['code'] == 'intermediate_order_total') {
				continue;
			}
			
			if (version_compare(VERSION, '2.2', '<')) {
				$this->load->model('total/' . $ot['code']);
				$this->{'model_total_' . $ot['code']}->getTotal($order_totals, $total, $taxes);
			} elseif (version_compare(VERSION, '2.3', '<')) {
				$this->load->model('total/' . $ot['code']);
				$this->{'model_total_' . $ot['code']}->getTotal($reference_array);
			} elseif (version_compare(VERSION, '4.0', '<')) {
				$this->load->model('extension/total/' . $ot['code']);
				$this->{'model_extension_total_' . $ot['code']}->getTotal($reference_array);
			} else {
				$this->load->model('extension/' . $ot['extension'] . '/total/' . $ot['code']);
				$getTotalFunction = $this->{'model_extension_' . $ot['extension'] . '_total_' . $ot['code']}->getTotal;
				$getTotalFunction($order_totals, $taxes, $total);
			}
		}
		
		return $reference_array;
	}
	
	//==============================================================================
	// cancelOrder()
	//==============================================================================
	public function cancelOrder($order_id, $reason) {
		// Check if payment link has been sent
		$order_history_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_history WHERE order_id = " . (int)$order_id . " AND `comment` LIKE '%Payment link sent to customer%'");
		if (!$order_history_query->num_rows) return;
		
		// Cancel order
		$settings = $this->getSettings();
		
		if (empty($settings['button_cancel_order_' . $this->session->data['language']])) {
			return;
		}
		
		$this->load->model('checkout/order');
		$order_info = $this->model_checkout_order->getOrder($order_id);
		$order_info['reason'] = $reason;
		
		$this->db->query("UPDATE `" . DB_PREFIX . "order` SET order_status_id = " . (int)$settings['canceled_status'] . " WHERE order_id = " . (int)$order_id);
		$this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = " . (int)$order_id . ", order_status_id = " . (int)$settings['canceled_status'] . ", notify = 0, comment = 'Order canceled by customer for the following reason: \"" . $this->db->escape($reason) . "\"', date_added = NOW()");
		
		// Send e-mail
		$this->send('canceled', $order_info);
	}
	
	//==============================================================================
	// sendPaymentLink()
	//==============================================================================
	public function sendPaymentLink($order_info, $order_status_id, $sent_from_admin = false) {
		// Check if link has already been sent
		if (!$sent_from_admin) {
			$order_history_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_history WHERE order_id = " . (int)$order_info['order_id'] . " AND `comment` LIKE '%Payment link sent to customer%'");
			if ($order_history_query->num_rows) return;
		}
		
		// Add payment link URL to order info
		$payment_page = (version_compare(VERSION, '4.0', '<')) ? 'extension/' . $this->type . '/collect' : 'extension/' . $this->name . '/' . $this->type . '/collect';
		$order_info['url'] = $order_info['store_url'] . 'index.php?route=' . $payment_page . '&order_id=' . $order_info['order_id'] . '&key=' . md5($this->config->get('config_encryption') . $order_info['order_id']);
		
		// Add order history note
		$comment = 'Payment link sent to customer: ' . $order_info['url'];
		if (!empty($order_info['note'])) {
			$comment .= '<br><br>With note: ' . $order_info['note'];
		}
		
		$this->db->query("UPDATE `" . DB_PREFIX . "order` SET order_status_id = " . (int)$order_status_id . " WHERE order_id = " . (int)$order_info['order_id']);
		$this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = " . (int)$order_info['order_id'] . ", order_status_id = " . (int)$order_status_id . ", notify = 1, comment = '" . $this->db->escape($comment) . "', date_added = NOW()");
		
		// Send e-mail
		$this->send('customer', $order_info);
	}
	
	//==============================================================================
	// sendAdminEmail()
	//==============================================================================
	public function sendAdminEmail($order_info) {
		// Get payment method info
		unset($this->session->data['payment_in_process']);
		$payment_code = (isset($this->session->data['payment_method']['code'])) ? $this->session->data['payment_method']['code'] : '';
		$payment_title = (isset($this->session->data['payment_methods'][$payment_code])) ? $this->session->data['payment_methods'][$payment_code]['title'] : '';
		
		// Change payment method on order
		$order_info['payment_code'] = $payment_code;
		$order_info['payment_method'] = $payment_title;
		$this->db->query("UPDATE `" . DB_PREFIX . "order` SET payment_method = '" . $this->db->escape($payment_title) . "', payment_code = '" . $this->db->escape($payment_code) . "' WHERE order_id = " . (int)$order_info['order_id']);
		
		// Add order history note
		$this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = " . (int)$order_info['order_id'] . ", order_status_id = " . (int)$order_info['order_status_id'] . ", notify = 0, comment = 'Customer completed payment', date_added = NOW()");
		
		// Send e-mail
		$this->send('admin', $order_info);
	}
	
	//==============================================================================
	// send()
	//==============================================================================
	private function send($email_type, $order_info) {
		$settings = $this->getSettings();
		
		// Set up e-mail
		$mail_options = array(
			'parameter'		=> $this->config->get('config_mail_parameter'),
			'smtp_hostname'	=> $this->config->get('config_mail_smtp_hostname'),
			'smtp_username' => $this->config->get('config_mail_smtp_username'),
			'smtp_password' => html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8'),
			'smtp_port'		=> $this->config->get('config_mail_smtp_port'),
			'smtp_timeout'	=> $this->config->get('config_mail_smtp_timeout'),
		);
		
		if (version_compare(VERSION, '2.0.2', '<')) {
			$mail = new Mail($this->config->get('config_mail'));
		} elseif (version_compare(VERSION, '4.0.2.0', '<')) {
			if (version_compare(VERSION, '3.0', '<')) {
				$mail = new Mail();
				$mail->protocol = $this->config->get('config_mail_protocol');
			} elseif (version_compare(VERSION, '4.0', '<')) {
				$mail = new Mail($this->config->get('config_mail_engine'));
			} else {
				$mail = new \Opencart\System\Library\Mail($this->config->get('config_mail_engine'));
			}
			
			foreach ($mail_options as $key => $value) {
				$mail->{$key} = $value;
			}
		} else {
			$mail = new \Opencart\System\Library\Mail($this->config->get('config_mail_engine'), $mail_options);
		}
		
		// Get order products
		$order_info['products'] = '';
		$order_products = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = " . (int)$order_info['order_id'])->rows;
		
		foreach ($order_products as $product) {
			$order_info['products'] .= $product['quantity'] . ' x ' . $product['name'] . ' (' . $product['model'] . ') ' . html_entity_decode($this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . '<br>';
			
			$order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_product_id = " . $product['order_product_id']);
			
			foreach ($order_option_query->rows as $option) {
				$value = ($option['type'] == 'file') ? utf8_substr($option['value'], 0, utf8_strrpos($option['value'], '.')) : $option['value'];
				$order_info['products'] .= ' - ' . $option['name'] . ': ' . $value . '<br>';
			}
		}
		
		// Set up shortcode replacements
		$replace = array('&amp;');
		$with = array('&');
		
		foreach ($order_info as $key => $value) {
			$replace[] = '[' . $key . ']';
			$with[] = (is_array($value)) ? print_r($value, true) : $value;
		}
		
		// Send e-mail
		$language = $this->db->query("SELECT * FROM " . DB_PREFIX . "language WHERE language_id = " . (int)$order_info['language_id'])->row['code'];
		
		$subject = html_entity_decode($settings[$email_type . '_subject_' . $language], ENT_QUOTES, 'UTF-8');
		$subject = str_replace($replace, $with, $subject);
		
		$html = html_entity_decode($settings[$email_type . '_message_' . $language], ENT_QUOTES, 'UTF-8');
		$html = str_replace($replace, $with, $html);
		
		$text = strip_tags(str_replace(array('<br>', '<p>', '</p>', "\n\n\n"), "\n", $html));
		
		if ($email_type == 'customer') {
			$to_emails = array($order_info['email']);
		} else {
			$to_emails = explode(',', $settings['admin_email']);
		}
		
		$store_email = $this->db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE store_id = " . (int)$order_info['store_id'] . " AND `key` = 'config_email'")->row['value'];
		
		$mail->setFrom($store_email);
		$mail->setSender(str_replace(array(',', '&'), array('', 'and'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8')));
		$mail->setSubject($subject);
		$mail->setHtml($html);
		$mail->setText($text);
		
		foreach ($to_emails as $to_email) {
			$mail->setTo(trim($to_email));
			$mail->send();
		}
	}
}
?>