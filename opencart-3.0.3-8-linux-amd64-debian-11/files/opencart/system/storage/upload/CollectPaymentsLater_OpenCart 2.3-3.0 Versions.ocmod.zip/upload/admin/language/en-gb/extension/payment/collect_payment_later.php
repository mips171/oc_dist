<?php
//==============================================================================
// Collect Payment Later v2023-5-05
// 
// Author: Clear Thinking, LLC
// E-mail: johnathan@getclearthinking.com
// Website: http://www.getclearthinking.com
// 
// All code within this file is copyright Clear Thinking, LLC.
// You may not copy or reuse code within this file without written permission.
//==============================================================================

$_['version'] = 'v2023-5-05';

//------------------------------------------------------------------------------
// Heading
//------------------------------------------------------------------------------
$_['heading_title']						= 'Collect Payment Later';
$_['text_collect_payment_later']		= '';

//------------------------------------------------------------------------------
// Send Payment Link text
//------------------------------------------------------------------------------
$_['button_send_payment_link']			= 'Send Payment Link';
$_['text_payment_link_sent']			= 'Payment link sent!';
$_['text_payment_link_note']			= 'Optionally enter a message sent to the customer with the payment link, which will replace the [note] shortcode in the e-mail template. You can also leave this field blank to not add any custom message.';

//------------------------------------------------------------------------------
// Extension Settings
//------------------------------------------------------------------------------
$_['tab_extension_settings']			= 'Extension Settings';
$_['heading_extension_settings']		= 'Extension Settings';

$_['entry_status']						= 'Status: <div class="help-text">Set the status for the extension as a payment option during checkout. You can leave this disabled and still send out payment links if you want. Links will still be sent out, and the payment page will still work, even if the extension is disabled.</div>';
$_['entry_check_for_updates']			= 'Check For Updates: <div class="help-text">Choose whether to automatically check for updates when the extension admin panel is loaded.</div>';
$_['entry_sort_order']					= 'Sort Order: <div class="help-text">Enter the sort order for the extension, relative to other payment methods.</div>';
$_['entry_title']						= 'Title: <div class="help-text">Enter the title for the payment method displayed to the customer during checkout. HTML is supported.</div>';
$_['entry_instructions']				= 'Instructions: <div class="help-text">Optionally enter some instructions displayed to the customer during the "Confirm" step of checkout. HTML is supported.</div>';
$_['entry_please_wait']					= '"Please Wait" Text: <div class="help-text">HTML is supported.</div>';
$_['entry_button_text']					= 'Button Text: <div class="help-text">Enter the text for the order confirmation button.</div>';
$_['entry_button_class']				= 'Button Class: <div class="help-text">Enter the CSS class for buttons in your theme.</div>';
$_['entry_button_styling']				= 'Button Styling: <div class="help-text">Optionally enter extra CSS styling for the button.</div>';
$_['entry_order_status_id']				= 'Order Status: <div class="help-text">Set the status applied to the order when this payment method is used to checkout.</div>';

//------------------------------------------------------------------------------
// Restrictions
//------------------------------------------------------------------------------
$_['tab_restrictions']					= 'Restrictions';
$_['heading_restrictions']				= 'Restrictions';

$_['entry_min_total']					= 'Minimum Total: <div class="help-text">Enter the minimum order total that must be reached before this payment method becomes active. Leave blank to have no restriction.</div>';
$_['entry_max_total']					= 'Maximum Total: <div class="help-text">Enter the maximum order total that can be reached before this payment method becomes inactive. Leave blank to have no restriction.</div>';
$_['entry_stores']						= 'Store(s): <div class="help-text">Select the stores that can use this payment method.</div>';

$_['entry_geo_zones']					= 'Geo Zone(s): <div class="help-text">Select the geo zones that can use this payment method. The "Everywhere Else" checkbox applies to any locations not within a geo zone.</div>';
$_['text_everywhere_else']				= '<em>Everywhere Else</em>';

$_['entry_customer_groups']				= 'Customer Group(s): <div class="help-text">Select the customer groups that can use this payment method. The "Guests" checkbox applies to all customers not logged in to an account.</div>';
$_['text_guests']						= '<em>Guests</em>';

$_['entry_currencies']					= 'Currencies: <div class="help-text">Select the currencies that can use this payment method.</div>';

//------------------------------------------------------------------------------
// Payment Page
//------------------------------------------------------------------------------
$_['tab_payment_page']					= 'Payment Page';
$_['heading_payment_page']				= 'Payment Page';

// Cancel Order Button
$_['heading_cancel_order_button']		= 'Cancel Order Button';
$_['entry_button_cancel_order']			= '"Cancel Order" Button: <div class="help-text">Enter the text for the "Cancel Order" button shown on the payment page, allowing the customer to cancel their order. Leave blank to hide the button.</div>';
$_['entry_text_confirmation_message']	= 'Confirmation Message: <div class="help-text">Enter the text shown to the customer after clicking the "Cancel Order" button, to confirm they want to cancel their order, and to let them enter a reason for cancellation.</div>';
$_['entry_text_success_message']		= 'Success Message: <div class="help-text">Enter the text shown to the customer their order is successfully canceled.</div>';
$_['entry_canceled_status']				= 'Canceled Order Status: <div class="help-text">Choose the order status assigned to the order if the customer cancels it.</div>';

// Payment Page
$_['heading_payment_page']				= 'Payment Page';
$_['entry_button_pay_now']				= '"Pay Now" Button: <div class="help-text">Enter the text for the "Pay Now" button shown on the customer\'s order history page. Leave blank to hide the button for all customers. If you send a customer a link and want to cancel the order, you can hide the "Pay Now" button for the order by entering this comment in the order history:<br><code>Order canceled by customer</code></div>';
$_['entry_require_logged']				= 'Require Customers to be Logged In for Payment: <div class="help-text">Choose whether to require customers to be logged in for the payment page, after the payment link has been sent to them.</div>';
$_['entry_show_terms_popup']			= 'Show Terms & Conditions Pop-up: <div class="help-text">Choose whether to display a pop-up on the payment page, requiring the customer to agree to the Terms & Conditions before being allowed to pay.</div>';
$_['entry_allow_payment_once']			= 'Only Allow Payment to Be Completed Once: <div class="help-text">Choose whether the payment can only be completed once, after which the payment link will become inaccessible.</div>';
$_['entry_payment_methods']				= 'Payment Methods Available: <div class="help-text">Select the payment methods available to the customer for use on the payment page. Note that you can even choose disabled payment methods here: if they are disabled they will not show up in the checkout, but WILL show up on the payment page.</div>';
$_['entry_text_payment_fee']			= '"Payment Method Fee" Text: <div class="help-text">Enter the text for the line item that is added if a payment method fee applies (which you can set below).</div>';
$_['entry_text_payment_discount']		= '"Payment Method Discount" Text: <div class="help-text">Enter the text for the line item that is added if a payment method discount applies (which you can set below)</div>';

// Payment Method Fees & Discounts
$_['heading_payment_method_fees']		= 'Payment Method Fees & Discounts';
$_['help_payment_method_fees']			= 'Optionally enter a fee or discount for each payment method. This will be applied to the order when the customer chooses to pay with that method on the payment page. Use normal decimals for fees (e.g. 5.00), negative decimals for discounts (e.g. -2.50), and a % symbol for percentages (e.g. 10%). To add both a flat fee and a percentage fee, use a + symbol in the middle, like this: <code>0.30 + 2.9%</code>. Fees and discounts are not taxable at this time, due to the difficulty of recalculating taxes in OpenCart.';

//------------------------------------------------------------------------------
// E-mail Settings
//------------------------------------------------------------------------------
$_['tab_email_settings']				= 'E-mail Settings';
$_['heading_email_settings']			= 'E-mail Settings';

$_['entry_email_order_status_id']		= 'Triggering Order Status: <div class="help-text">Set the order status that triggers sending the customer e-mail to collect payment. Choose "--- Manually Trigger Only ---" to only send the e-mail when the "Send Payment Link" button is clicked in Sales > Orders.</div>';
$_['text_manually_trigger_only']		= '--- Manually Trigger Only ---';

$_['entry_customer_subject']			= 'Customer E-mail Subject: <div class="help-text">Supports any of the shortcodes listed below.</div>';
$_['entry_customer_message']			= 'Customer E-mail Message: <div class="help-text">Use <code>[url]</code> in place of the payment page URL. Use <code>[note]</code> in place of the custom message you can enter when manually clicking the "Send Payment Link" button. This field also supports any of the shortcodes listed below.</div>';
$_['entry_admin_email']					= 'Admin E-mail Address(es): <div class="help-text">Enter the e-mail address(es) that are notified of a successful payment made using the payment link sent to the customer.</div>';
$_['entry_admin_subject']				= 'Admin E-mail Subject: <div class="help-text">This field supports any of the shortcodes listed below.</div>';
$_['entry_admin_message']				= 'Admin E-mail Message: <div class="help-text">This field supports any of the shortcodes listed below.</div>';
$_['entry_canceled_subject']			= 'Canceled Order Subject: <div class="help-text">This field supports any of the shortcodes listed below.</div>';
$_['entry_canceled_message']			= 'Canceled Order Message: <div class="help-text">This field supports any of the shortcodes listed below, as well as the [reason] shortcode for the cancellation reason entered by the customer.</div>';

$_['heading_shortcodes']				= 'Shortcodes';

//------------------------------------------------------------------------------
// Standard Text
//------------------------------------------------------------------------------
$_['contact_url']						= 'https://www.getclearthinking.com/contact?store_url=' . str_replace('www.', '', $_SERVER['HTTP_HOST']) . '&version=' . VERSION;
$_['copyright']							= '<hr><div class="text-center" style="margin: 15px">' . $_['heading_title'] . ' (' . $_['version'] . ') &copy; <a target="_blank" href="' . $_['contact_url'] . '">Clear Thinking, LLC</a></div>';

$_['standard_autosaving_enabled']		= 'Auto-Saving Enabled';
$_['standard_confirm']					= 'This operation cannot be undone. Continue?';
$_['standard_error']					= '<strong>Error:</strong> You do not have permission to modify ' . $_['heading_title'] . '!';
$_['standard_max_input_vars']			= '<strong>Warning:</strong> The number of settings is close to your <code>max_input_vars</code> server value. You should enable auto-saving to avoid losing any data.';
$_['standard_please_wait']				= 'Please wait...';
$_['standard_saved']					= 'Saved!';
$_['standard_saving']					= 'Saving...';
$_['standard_select']					= '--- Select ---';
$_['standard_success']					= 'Success!';
$_['standard_testing_mode']				= "Your log is too large to open! If you need to archive it, you can download it using the button above.\n\nTo start a new log, (1) click the Clear Log button, (2) reload the admin panel page, then (3) run your test again.";

$_['standard_check_for_updates']		= 'Check For Updates';
$_['standard_contact_clear_thinking']	= 'Contact Clear Thinking';
$_['standard_error_checking']			= 'There was an error checking for the latest version.';
$_['standard_using_latest']				= 'You are using the latest version';
$_['standard_new_version']				= 'A new version is available!';
$_['standard_your_version']				= 'Your Version:';
$_['standard_latest_version']			= 'Latest Version:';
$_['standard_release_notes']			= 'View release notes';
$_['standard_continue']					= 'Continue';
$_['standard_update_warning']			= '<ul><li>Before updating, it is highly recommended to <b>back up your website files</b>.</li><br><li>To update, enter your license key below and click "Update". A license comes with 1 year of free updates, so you may not qualify for the latest version if you are beyond that period. If that is the case, you will be notified after attempting to update.</li><br><li>Updating the extension will <b>overwrite all current extension files</b>. If you have made modifications to any files, make sure you back up your edits before updating.</li><br><li>If any issues occur during or after updating, download and reinstall the extension manually.</li><br><li>If you have lost your license key or download link, you can retrieve them <a target="_blank" href="https://www.getclearthinking.com/downloads/license">on this page</a>.</li></ul><br>';
$_['standard_update']					= 'Update';
$_['standard_updating']					= 'Updating...';
$_['standard_license_key']				= 'License Key:';

$_['standard_module']					= 'Modules';
$_['standard_shipping']					= 'Shipping';
$_['standard_payment']					= 'Payments';
$_['standard_total']					= 'Order Totals';
$_['standard_feed']						= 'Feeds';
?>