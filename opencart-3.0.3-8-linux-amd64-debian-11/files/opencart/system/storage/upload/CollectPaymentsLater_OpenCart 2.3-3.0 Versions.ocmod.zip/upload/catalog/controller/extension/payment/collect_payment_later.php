<?php
//==============================================================================
// Collect Payment Later v2023-5-05
// 
// Author: Clear Thinking, LLC
// E-mail: johnathan@getclearthinking.com
// Website: http://www.getclearthinking.com
// 
// All code within this file is copyright Clear Thinking, LLC.
// You may not copy or reuse code within this file without written permission.
//==============================================================================

//namespace Opencart\Catalog\Controller\Extension\CollectPaymentLater\Payment;
//class CollectPaymentLater extends \Opencart\System\Engine\Controller {

class ControllerExtensionPaymentCollectPaymentLater extends Controller {
	
	private $type = 'payment';
	private $name = 'collect_payment_later';
	
	public function logFatalErrors() {
		$error = error_get_last();
		if ($error && $error['type'] === E_ERROR) {
			$this->log->write(strtoupper($this->name) . ': Order could not be completed due to the following fatal error:');
			$this->log->write('PHP Fatal Error:  ' . $error['message'] . ' in ' . $error['file'] . ' on line ' . $error['line']);
		}
	}
	
	//==============================================================================
	// index()
	//==============================================================================
	public function index() {
		register_shutdown_function(array($this, 'logFatalErrors'));
		
		$data['type'] = $this->type;
		$data['name'] = $this->name;
		$data['settings'] = $this->getSettings();
		
		$data['language'] = (isset($this->session->data['language'])) ? $this->session->data['language'] : $this->config->get('config_language');
		$data['checkout_success'] = $this->url->link('checkout/success', '', 'SSL');
		
		// Render
		$theme = (version_compare(VERSION, '2.2', '<')) ? $this->config->get('config_template') : $this->config->get('theme_default_directory');
		$template = (file_exists(DIR_TEMPLATE . $theme . '/template/extension/' . $this->type . '/' . $this->name . '.twig')) ? $theme : 'default';
		
		if (version_compare(VERSION, '4.0', '<')) {
			$template_file = DIR_TEMPLATE . $template . '/template/extension/' . $this->type . '/' . $this->name . '.twig';
		} elseif (defined('DIR_EXTENSION')) {
			$template_file = DIR_EXTENSION . $this->name . '/catalog/view/template/' . $this->type . '/' . $this->name . '.twig';
		}
		
		if (is_file($template_file)) {
			extract($data);
			
			ob_start();
			if (version_compare(VERSION, '4.0', '<')) {
				require(class_exists('VQMod') ? \VQMod::modCheck(modification($template_file)) : modification($template_file));
			} else {
				require(class_exists('VQMod') ? \VQMod::modCheck($template_file) : $template_file);
			}
			$output = ob_get_clean();
			
			if (version_compare(VERSION, '4.0', '>=')) {
				$separator = (version_compare(VERSION, '4.0.2.0', '<')) ? '|' : '.';
				$output = str_replace($settings['extension_route'] . '/', $settings['extension_route'] . $separator, $output);
			}
			
			return $output;
		} else {
			return 'Error loading template file: ' . $template_file;
		}
	}
	
	//==============================================================================
	// getSettings()
	//==============================================================================
	private function getSettings() {
		$code = (version_compare(VERSION, '3.0', '<') ? '' : $this->type . '_') . $this->name;
		
		$settings = array();
		$settings_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE `code` = '" . $this->db->escape($code) . "' ORDER BY `key` ASC");
		
		foreach ($settings_query->rows as $setting) {
			$value = $setting['value'];
			if ($setting['serialized']) {
				$value = (version_compare(VERSION, '2.1', '<')) ? unserialize($setting['value']) : json_decode($setting['value'], true);
			}
			$split_key = preg_split('/_(\d+)_?/', str_replace($code . '_', '', $setting['key']), -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
			
				if (count($split_key) == 1)	$settings[$split_key[0]] = $value;
			elseif (count($split_key) == 2)	$settings[$split_key[0]][$split_key[1]] = $value;
			elseif (count($split_key) == 3)	$settings[$split_key[0]][$split_key[1]][$split_key[2]] = $value;
			elseif (count($split_key) == 4)	$settings[$split_key[0]][$split_key[1]][$split_key[2]][$split_key[3]] = $value;
			else 							$settings[$split_key[0]][$split_key[1]][$split_key[2]][$split_key[3]][$split_key[4]] = $value;
		}
		
		if (version_compare(VERSION, '4.0', '<')) {
			$settings['extension_route'] = 'extension/' . $this->type . '/' . $this->name;
		} else {
			$settings['extension_route'] = 'extension/' . $this->name . '/' . $this->type . '/' . $this->name;
		}
		
		return $settings;
	}
	
	//==============================================================================
	// confirm()
	//==============================================================================
	public function confirm() {
		register_shutdown_function(array($this, 'logFatalErrors'));
		$settings = $this->getSettings();
		
		if (version_compare(VERSION, '4.0', '<')) {
			$payment_code = (isset($this->session->data['payment_method']['code'])) ? $this->session->data['payment_method']['code'] : '';
			$separator = '/';
		} elseif (version_compare(VERSION, '4.0.2.0', '<')) {
			$payment_code = (isset($this->session->data['payment_method'])) ? $this->session->data['payment_method'] : '';
			$separator = '|';
		} else {
			$payment_code = (isset($this->session->data['payment_method']['code'])) ? substr($this->session->data['payment_method']['code'], 0, strpos($this->session->data['payment_method']['code'], '.')) : '';
			$separator = '.';
		}
		
		if ($payment_code != $this->name) {
			$this->log->write(strtoupper($this->name) . ': The URL with "route=' . $settings['extension_route'] . $separator . 'confirm" was accessed improperly by IP address ' . $this->request->server['REMOTE_ADDR']);
			return;
		}
		
		$this->load->model('checkout/order');
		
		if (version_compare(VERSION, '4.0', '<')) {
			$this->model_checkout_order->addOrderHistory($this->session->data['order_id'], $settings['order_status_id']);
		} else {
			$this->model_checkout_order->addHistory($this->session->data['order_id'], $settings['order_status_id']);
		}
	}
	
	//==============================================================================
	// Event hooks
	//==============================================================================
	public function sendPaymentLink(&$route = '', &$input = array(), &$output = array()) {
		$settings = $this->getSettings();
		
		if (version_compare(VERSION, '4.0', '<')) {
			$input = $route;
		}
		
		$order_id = $input[0];
		$this->load->model('checkout/order');
		$order_info = $this->model_checkout_order->getOrder($order_id);
		
		if ($order_info['order_status_id'] > 0 && $order_info['order_status_id'] == $settings['email_order_status_id']) {
			if (version_compare(VERSION, '4.0', '<')) {
				$this->load->model('extension/' . $this->type . '/' . $this->name);
				$model = $this->{'model_extension_' . $this->type . '_' . $this->name};
			} else {
				$this->load->model('extension/' . $this->name . '/' . $this->type . '/' . $this->name);
				$model = $this->{'model_extension_' . $this->name . '_' . $this->type . '_' . $this->name};
			}
			
			$model->sendPaymentLink($order_info, $order_info['order_status_id']);
		}
	}
	
	public function sendAdminEmail(&$route = '', &$input = array()) {
		if (empty($this->session->data['payment_in_process'])) {
			return;
		}
		
		$order_id = $this->session->data['order_id'];
		$payment_link_sent_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_history WHERE order_id = " . (int)$order_id . " AND `comment` LIKE '%Payment link sent to customer%'");
		$customer_completed_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_history WHERE order_id = " . (int)$order_id . " AND `comment` = 'Customer completed payment'");
		
		if ($payment_link_sent_query->num_rows && !$customer_completed_query->num_rows) {
			$this->load->model('checkout/order');
			$order_info = $this->model_checkout_order->getOrder($order_id);
			
			if (version_compare(VERSION, '4.0', '<')) {
				$this->load->model('extension/' . $this->type . '/' . $this->name);
				$model = $this->{'model_extension_' . $this->type . '_' . $this->name};
			} else {
				$this->load->model('extension/' . $this->name . '/' . $this->type . '/' . $this->name);
				$model = $this->{'model_extension_' . $this->name . '_' . $this->type . '_' . $this->name};
			}
			
			$model->sendAdminEmail($order_info);
		}
	}
	
	public function addButton(&$route = '', &$input = array()) {
		$settings = $this->getSettings();
		$language = (isset($this->session->data['language'])) ? $this->session->data['language'] : $this->config->get('config_language');
		
		if (empty($settings['button_pay_now_' . $language])) {
			return;
		}
		
		if (version_compare(VERSION, '4.0', '<')) {
			$input = $route;
		}
		
		foreach ($input['orders'] as &$order) {
			$payment_link_sent_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_history WHERE order_id = " . (int)$order['order_id'] . " AND `comment` LIKE '%Payment link sent to customer%'");
			$customer_completed_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_history WHERE order_id = " . (int)$order['order_id'] . " AND `comment` = 'Customer completed payment'");
			$order_canceled_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_history WHERE order_id = " . (int)$order['order_id'] . " AND `comment` LIKE '%Order canceled by customer%'");
			
			if ($payment_link_sent_query->num_rows && !$customer_completed_query->num_rows && !$order_canceled_query->num_rows) {
				$payment_page = (version_compare(VERSION, '4.0', '<')) ? 'extension/' . $this->type . '/collect' : 'extension/' . $this->name . '/' . $this->type . '/collect';
				$paynow_link = 'index.php?route=' . $payment_page . '&order_id=' . $order['order_id'] . '&key=' . md5($this->config->get('config_encryption') . $order['order_id']);
				$order['view'] = $paynow_link . '" class="btn btn-success">' . $settings['button_pay_now_' . $language] . '</a> <a href="' . $order['view'];
			}
		}
		
		if (version_compare(VERSION, '4.0', '<')) {
			return $input;
		}
	}
}
?>